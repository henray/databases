INSERT INTO team VALUES	('Boston Celtics', '00001');
INSERT INTO team VALUES	('Brooklyn Nets', '00002');
INSERT INTO team VALUES	('New York Knicks', '00003');
INSERT INTO team VALUES	('Philadelphia 76ers', '00004');
INSERT INTO team VALUES	('Toronto Raptors', '00005');
